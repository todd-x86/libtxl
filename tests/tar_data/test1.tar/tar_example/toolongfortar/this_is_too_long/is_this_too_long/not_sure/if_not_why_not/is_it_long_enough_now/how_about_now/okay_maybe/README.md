can you read me?
